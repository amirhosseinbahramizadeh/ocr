import logging

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

from app.api.routes import router
from app.core.config import get_settings
from app.core.exceptions import PassportOCRError

settings = get_settings()
logger = logging.getLogger("uvicorn.error")

app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description=(
        "وب‌سرویس OCR پاسپورت عراقی با PassportEye برای MRZ و EasyOCR برای متن عربی صفحه. "
        "Swagger در مسیر /docs و ReDoc در مسیر /redoc در دسترس است."
    ),
    docs_url="/docs",
    redoc_url="/redoc",
)

app.include_router(router)


@app.exception_handler(PassportOCRError)
async def passport_ocr_error_handler(_: Request, exc: PassportOCRError) -> JSONResponse:
    return JSONResponse(
        status_code=exc.status_code,
        content={"success": False, "error": {"code": exc.code, "message": exc.message}},
    )


@app.exception_handler(RequestValidationError)
async def validation_error_handler(_: Request, exc: RequestValidationError) -> JSONResponse:
    return JSONResponse(
        status_code=422,
        content={
            "success": False,
            "error": {
                "code": "REQUEST_VALIDATION_ERROR",
                "message": "درخواست ارسالی معتبر نیست. فایل و پارامترهای ورودی را بررسی کنید.",
            },
        },
    )


@app.exception_handler(Exception)
async def generic_error_handler(request: Request, exc: Exception) -> JSONResponse:
    logger.error(
        "Unhandled error on %s",
        request.url.path,
        exc_info=(type(exc), exc, exc.__traceback__),
    )
    return JSONResponse(
        status_code=500,
        content={
            "success": False,
            "error": {
                "code": "INTERNAL_SERVER_ERROR",
                "message": "خطای داخلی سرویس رخ داد.",
            },
        },
    )


@app.get("/", tags=["System"], summary="صفحه اصلی سرویس")
def root() -> dict[str, object]:
    return {
        "success": True,
        "message": "سرویس OCR پاسپورت عراقی فعال است.",
        "swagger": "/docs",
        "health": "/api/v1/health",
        "ocr_endpoint": "/api/v1/passport/ocr",
    }
