from typing import Any
from pydantic import BaseModel, Field


class OCRLine(BaseModel):
    text: str
    confidence: float = Field(ge=0.0, le=1.0)
    bbox: list[list[int]]


class ArabicVisualFields(BaseModel):
    passport_number: str | None = None
    full_name_ar: str | None = None
    surname_ar: str | None = None
    given_names_ar: str | None = None
    place_of_birth_ar: str | None = None
    date_of_birth_text: str | None = None
    date_of_issue_text: str | None = None
    date_of_expiry_text: str | None = None
    sex_text: str | None = None
    raw_lines: list[OCRLine] = Field(default_factory=list)


class MRZFields(BaseModel):
    mrz_type: str | None = None
    document_type: str | None = None
    issuing_country: str | None = None
    nationality: str | None = None
    passport_number: str | None = None
    surname: str | None = None
    given_names: str | None = None
    date_of_birth: str | None = None
    sex: str | None = None
    expiration_date: str | None = None
    personal_number: str | None = None
    raw_text: str | None = None
    valid_score: int | None = None
    checks: dict[str, bool | None] = Field(default_factory=dict)
    source: dict[str, Any] = Field(default_factory=dict)


class ValidationResult(BaseModel):
    is_iraqi_passport: bool
    mrz_checks_passed: bool
    warnings: list[str] = Field(default_factory=list)


class PassportData(BaseModel):
    passport_number: str | None = None
    surname_latin: str | None = None
    given_names_latin: str | None = None
    full_name_ar: str | None = None
    surname_ar: str | None = None
    given_names_ar: str | None = None
    nationality: str | None = None
    issuing_country: str | None = None
    date_of_birth: str | None = None
    sex: str | None = None
    expiration_date: str | None = None
    place_of_birth_ar: str | None = None


class PassportOCRResponse(BaseModel):
    success: bool = True
    message: str = "اطلاعات پاسپورت با موفقیت استخراج شد."
    data: PassportData
    mrz: MRZFields
    visual_fields: ArabicVisualFields
    validation: ValidationResult


class ErrorDetail(BaseModel):
    code: str
    message: str


class ErrorResponse(BaseModel):
    success: bool = False
    error: ErrorDetail
