import os
import shutil
import tempfile
from dataclasses import dataclass
from typing import Any

import cv2
import numpy as np
from passporteye import read_mrz

from app.core.exceptions import MRZNotFoundError, TesseractNotFoundError


@dataclass(slots=True)
class MRZCropResult:
    """PassportEye output plus the detected MRZ image region."""

    source: dict[str, Any]
    roi: np.ndarray | None


class MRZCropper:
    """Locate/crop MRZ with PassportEye and keep its parsed metadata."""

    def crop(self, image: np.ndarray) -> MRZCropResult:
        if shutil.which("tesseract") is None:
            raise TesseractNotFoundError()

        fd, path = tempfile.mkstemp(suffix=".png")
        os.close(fd)
        try:
            if not cv2.imwrite(path, image):
                raise MRZNotFoundError()

            mrz = read_mrz(path, save_roi=True)
            if mrz is None:
                raise MRZNotFoundError()

            source: dict[str, Any] = mrz.to_dict()
            aux = getattr(mrz, "aux", None) or {}
            roi = aux.get("roi")
            return MRZCropResult(source=source, roi=roi)
        finally:
            try:
                os.remove(path)
            except OSError:
                pass
