from typing import Any

from app.models.schemas import MRZFields


class MRZParser:
    """Map PassportEye's dictionary to a stable API schema."""

    @staticmethod
    def _clean(value: Any) -> str | None:
        if value is None:
            return None
        text = str(value).strip().replace("<", " ")
        return " ".join(text.split()) or None

    def parse(self, source: dict[str, Any]) -> MRZFields:
        checks = {
            "passport_number": source.get("valid_number"),
            "date_of_birth": source.get("valid_date_of_birth"),
            "expiration_date": source.get("valid_expiration_date"),
            "composite": source.get("valid_composite"),
        }
        given = source.get("names") or source.get("given_names")
        raw_text = source.get("raw_text")
        if not raw_text:
            raw_text = "\n".join(
                str(source.get(key, ""))
                for key in ("line1", "line2", "line3")
                if source.get(key)
            ) or None

        return MRZFields(
            mrz_type=self._clean(source.get("mrz_type")),
            document_type=self._clean(source.get("type")),
            issuing_country=self._clean(source.get("country")),
            nationality=self._clean(source.get("nationality")),
            passport_number=self._clean(source.get("number")),
            surname=self._clean(source.get("surname")),
            given_names=self._clean(given),
            date_of_birth=self._clean(source.get("date_of_birth")),
            sex=self._clean(source.get("sex")),
            expiration_date=self._clean(source.get("expiration_date")),
            personal_number=self._clean(source.get("personal_number") or source.get("optional1")),
            raw_text=raw_text,
            valid_score=source.get("valid_score"),
            checks=checks,
            source=source,
        )
