import re
import threading

import easyocr
import numpy as np

from app.models.schemas import ArabicVisualFields, OCRLine


class ArabicPageOCR:
    """EasyOCR wrapper for Arabic/English text in the visual inspection zone."""

    _reader = None
    _lock = threading.Lock()

    FIELD_PATTERNS: dict[str, tuple[str, ...]] = {
        "passport_number": (r"(?:رقم\s*(?:الجواز|جواز\s*السفر))\s*[:：-]?\s*(.+)",),
        "full_name_ar": (r"(?:الاسم\s*الكامل|الاسم)\s*[:：-]?\s*(.+)",),
        "surname_ar": (r"(?:اللقب|اسم\s*العائلة)\s*[:：-]?\s*(.+)",),
        "given_names_ar": (r"(?:الاسماء|الأسماء|الاسم\s*الأول)\s*[:：-]?\s*(.+)",),
        "place_of_birth_ar": (r"(?:محل|مكان)\s*الولادة\s*[:：-]?\s*(.+)",),
        "date_of_birth_text": (r"تاريخ\s*الولادة\s*[:：-]?\s*(.+)",),
        "date_of_issue_text": (r"تاريخ\s*(?:الاصدار|الإصدار)\s*[:：-]?\s*(.+)",),
        "date_of_expiry_text": (r"تاريخ\s*(?:الانتهاء|النفاذ)\s*[:：-]?\s*(.+)",),
        "sex_text": (r"(?:الجنس|النوع)\s*[:：-]?\s*(.+)",),
    }

    def __init__(self, languages: tuple[str, ...] = ("ar", "en"), gpu: bool = False, min_confidence: float = 0.25):
        self.languages = list(languages)
        self.gpu = gpu
        self.min_confidence = min_confidence

    def _get_reader(self):
        if ArabicPageOCR._reader is None:
            with ArabicPageOCR._lock:
                if ArabicPageOCR._reader is None:
                    ArabicPageOCR._reader = easyocr.Reader(self.languages, gpu=self.gpu)
        return ArabicPageOCR._reader

    def read(self, image: np.ndarray) -> ArabicVisualFields:
        reader = self._get_reader()
        result = reader.readtext(
            image,
            detail=1,
            paragraph=False,
            decoder="greedy",
        )

        lines: list[OCRLine] = []
        accepted_texts: list[str] = []
        for bbox, text, confidence in result:
            confidence = float(confidence)
            if confidence < self.min_confidence:
                continue
            normalized = self._normalize_text(text)
            if not normalized:
                continue
            int_bbox = [[int(round(p[0])), int(round(p[1]))] for p in bbox]
            lines.append(OCRLine(text=normalized, confidence=confidence, bbox=int_bbox))
            accepted_texts.append(normalized)

        parsed = self._parse_fields(accepted_texts)
        return ArabicVisualFields(raw_lines=lines, **parsed)

    @staticmethod
    def _normalize_text(text: str) -> str:
        text = text.replace("ـ", " ").strip()
        text = re.sub(r"\s+", " ", text)
        return text

    def _parse_fields(self, texts: list[str]) -> dict[str, str | None]:
        joined = "\n".join(texts)
        output: dict[str, str | None] = {name: None for name in self.FIELD_PATTERNS}
        for field, patterns in self.FIELD_PATTERNS.items():
            for pattern in patterns:
                match = re.search(pattern, joined, flags=re.IGNORECASE)
                if match:
                    value = match.group(1).strip(" :-|\t")
                    output[field] = value or None
                    break
        return output
