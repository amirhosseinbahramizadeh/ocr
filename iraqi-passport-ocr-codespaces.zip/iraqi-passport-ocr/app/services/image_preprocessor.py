import cv2
import numpy as np

from app.core.exceptions import InvalidImageError


class ImagePreprocessor:
    """Decode, normalize, deskew and enhance passport images."""

    def decode(self, content: bytes) -> np.ndarray:
        if not content:
            raise InvalidImageError("فایل تصویر خالی است.")
        array = np.frombuffer(content, dtype=np.uint8)
        image = cv2.imdecode(array, cv2.IMREAD_COLOR)
        if image is None or image.size == 0:
            raise InvalidImageError()
        return image

    def normalize(self, image: np.ndarray, max_width: int = 1800) -> np.ndarray:
        h, w = image.shape[:2]
        if w <= max_width:
            return image.copy()
        ratio = max_width / float(w)
        return cv2.resize(image, (max_width, int(h * ratio)), interpolation=cv2.INTER_AREA)

    def deskew(self, image: np.ndarray) -> np.ndarray:
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        edges = cv2.Canny(gray, 60, 180)
        lines = cv2.HoughLinesP(edges, 1, np.pi / 180, 120, minLineLength=image.shape[1] // 3, maxLineGap=25)
        if lines is None:
            return image

        # OpenCV versions may return HoughLinesP as (N, 1, 4) or (N, 4).
        # Reshaping makes the code compatible with both layouts.
        normalized_lines = np.asarray(lines).reshape(-1, 4)

        angles: list[float] = []
        for x1, y1, x2, y2 in normalized_lines:
            if x2 == x1:
                continue
            angle = np.degrees(np.arctan2(y2 - y1, x2 - x1))
            if -12 <= angle <= 12:
                angles.append(angle)

        if not angles:
            return image

        angle = float(np.median(angles))
        if abs(angle) < 0.25:
            return image

        h, w = image.shape[:2]
        matrix = cv2.getRotationMatrix2D((w / 2, h / 2), angle, 1.0)
        return cv2.warpAffine(
            image,
            matrix,
            (w, h),
            flags=cv2.INTER_CUBIC,
            borderMode=cv2.BORDER_REPLICATE,
        )

    def enhance_for_ocr(self, image: np.ndarray) -> np.ndarray:
        lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
        l_channel, a_channel, b_channel = cv2.split(lab)
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        l_channel = clahe.apply(l_channel)
        enhanced = cv2.merge((l_channel, a_channel, b_channel))
        enhanced = cv2.cvtColor(enhanced, cv2.COLOR_LAB2BGR)
        return cv2.bilateralFilter(enhanced, 5, 30, 30)

    def process(self, content: bytes) -> np.ndarray:
        image = self.decode(content)
        image = self.normalize(image)
        image = self.deskew(image)
        return self.enhance_for_ocr(image)
