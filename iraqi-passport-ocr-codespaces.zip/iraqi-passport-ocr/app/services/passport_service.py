from app.models.schemas import PassportData, PassportOCRResponse
from app.services.image_preprocessor import ImagePreprocessor
from app.services.mrz_cropper import MRZCropper
from app.services.mrz_parser import MRZParser
from app.services.ocr_service import ArabicPageOCR
from app.services.validator import PassportValidator


class PassportOCRService:
    def __init__(
        self,
        preprocessor: ImagePreprocessor,
        mrz_cropper: MRZCropper,
        mrz_parser: MRZParser,
        arabic_ocr: ArabicPageOCR,
        validator: PassportValidator,
    ):
        self.preprocessor = preprocessor
        self.mrz_cropper = mrz_cropper
        self.mrz_parser = mrz_parser
        self.arabic_ocr = arabic_ocr
        self.validator = validator

    def process(self, content: bytes) -> PassportOCRResponse:
        image = self.preprocessor.process(content)

        # PassportEye detects/crops MRZ and also exposes parsed MRZ metadata.
        mrz_crop = self.mrz_cropper.crop(image)
        mrz = self.mrz_parser.parse(mrz_crop.source)

        # EasyOCR is intentionally applied to the visual zone/page text, not to MRZ.
        visual = self.arabic_ocr.read(image)
        validation = self.validator.validate(mrz)

        data = PassportData(
            passport_number=mrz.passport_number or visual.passport_number,
            surname_latin=mrz.surname,
            given_names_latin=mrz.given_names,
            full_name_ar=visual.full_name_ar,
            surname_ar=visual.surname_ar,
            given_names_ar=visual.given_names_ar,
            nationality=mrz.nationality,
            issuing_country=mrz.issuing_country,
            date_of_birth=mrz.date_of_birth or visual.date_of_birth_text,
            sex=mrz.sex or visual.sex_text,
            expiration_date=mrz.expiration_date or visual.date_of_expiry_text,
            place_of_birth_ar=visual.place_of_birth_ar,
        )

        return PassportOCRResponse(
            data=data,
            mrz=mrz,
            visual_fields=visual,
            validation=validation,
        )
