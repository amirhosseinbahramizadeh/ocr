from app.models.schemas import MRZFields, ValidationResult


class PassportValidator:
    """Business validation for an Iraqi passport and MRZ consistency."""

    def __init__(self, iraq_country_code: str = "IRQ"):
        self.iraq_country_code = iraq_country_code.upper()

    def validate(self, mrz: MRZFields) -> ValidationResult:
        warnings: list[str] = []
        issuing = (mrz.issuing_country or "").upper()
        nationality = (mrz.nationality or "").upper()

        is_iraqi = issuing == self.iraq_country_code or nationality == self.iraq_country_code
        if not is_iraqi:
            warnings.append("کد کشور/تابعیت MRZ برابر IRQ نیست؛ تصویر ممکن است متعلق به پاسپورت عراقی نباشد.")

        check_values = [value for value in mrz.checks.values() if value is not None]
        mrz_checks_passed = bool(check_values) and all(check_values)
        if not check_values:
            warnings.append("PassportEye نتیجه صریحی برای کنترل checksumهای MRZ برنگرداند.")
        elif not mrz_checks_passed:
            warnings.append("حداقل یکی از checksumهای MRZ معتبر نیست؛ نتیجه OCR باید بازبینی شود.")

        if mrz.valid_score is not None and mrz.valid_score < 80:
            warnings.append(f"امتیاز اعتبار MRZ پایین است ({mrz.valid_score}).")

        return ValidationResult(
            is_iraqi_passport=is_iraqi,
            mrz_checks_passed=mrz_checks_passed,
            warnings=warnings,
        )
