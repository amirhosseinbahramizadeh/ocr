from functools import lru_cache

from fastapi import APIRouter, Depends, File, UploadFile

from app.core.config import Settings, get_settings
from app.core.exceptions import FileTooLargeError, UnsupportedFileTypeError
from app.models.schemas import ErrorResponse, PassportOCRResponse
from app.services.image_preprocessor import ImagePreprocessor
from app.services.mrz_cropper import MRZCropper
from app.services.mrz_parser import MRZParser
from app.services.ocr_service import ArabicPageOCR
from app.services.passport_service import PassportOCRService
from app.services.validator import PassportValidator

router = APIRouter(prefix="/api/v1", tags=["Passport OCR"])


@lru_cache
def get_service() -> PassportOCRService:
    settings = get_settings()
    return PassportOCRService(
        preprocessor=ImagePreprocessor(),
        mrz_cropper=MRZCropper(),
        mrz_parser=MRZParser(),
        arabic_ocr=ArabicPageOCR(
            languages=settings.easyocr_languages,
            gpu=settings.easyocr_gpu,
            min_confidence=settings.min_ocr_confidence,
        ),
        validator=PassportValidator(settings.iraq_country_code),
    )


@router.get("/health", summary="بررسی سلامت سرویس")
def health() -> dict[str, str]:
    return {"status": "ok"}


@router.post(
    "/passport/ocr",
    response_model=PassportOCRResponse,
    responses={
        400: {"model": ErrorResponse, "description": "تصویر نامعتبر"},
        413: {"model": ErrorResponse, "description": "فایل بیش از حد بزرگ"},
        415: {"model": ErrorResponse, "description": "فرمت نامعتبر"},
        422: {"model": ErrorResponse, "description": "MRZ پیدا نشد یا OCR ناموفق بود"},
        500: {"model": ErrorResponse, "description": "خطای داخلی سرویس"},
    },
    summary="استخراج اطلاعات پاسپورت عراقی",
    description=(
        "تصویر صفحه مشخصات پاسپورت را دریافت می‌کند؛ MRZ با PassportEye "
        "و متن عربی صفحه با EasyOCR استخراج می‌شود."
    ),
)
async def passport_ocr(
    file: UploadFile = File(..., description="تصویر JPEG/PNG/WEBP از صفحه مشخصات پاسپورت"),
    settings: Settings = Depends(get_settings),
    service: PassportOCRService = Depends(get_service),
) -> PassportOCRResponse:
    if file.content_type not in settings.allowed_content_types:
        raise UnsupportedFileTypeError()

    content = await file.read(settings.max_upload_mb * 1024 * 1024 + 1)
    if len(content) > settings.max_upload_mb * 1024 * 1024:
        raise FileTooLargeError(settings.max_upload_mb)

    return service.process(content)
