from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "Iraqi Passport OCR API"
    app_version: str = "1.0.0"
    max_upload_mb: int = 12
    easyocr_gpu: bool = False
    easyocr_languages: tuple[str, ...] = ("ar", "en")
    allowed_content_types: tuple[str, ...] = (
        "image/jpeg",
        "image/png",
        "image/webp",
    )
    iraq_country_code: str = "IRQ"
    min_ocr_confidence: float = 0.25

    model_config = SettingsConfigDict(
        env_prefix="PASSPORT_OCR_",
        env_file=".env",
        extra="ignore",
    )


@lru_cache
def get_settings() -> Settings:
    return Settings()
