class PassportOCRError(Exception):
    """Base domain exception with a Persian user-facing message."""

    def __init__(self, message: str, status_code: int = 422, code: str = "OCR_ERROR"):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.code = code


class InvalidImageError(PassportOCRError):
    def __init__(self, message: str = "تصویر ارسالی معتبر نیست یا قابل خواندن نیست."):
        super().__init__(message, 400, "INVALID_IMAGE")


class UnsupportedFileTypeError(PassportOCRError):
    def __init__(self):
        super().__init__(
            "فرمت فایل پشتیبانی نمی‌شود. فقط JPEG، PNG و WEBP مجاز است.",
            415,
            "UNSUPPORTED_FILE_TYPE",
        )


class FileTooLargeError(PassportOCRError):
    def __init__(self, max_mb: int):
        super().__init__(
            f"حجم فایل بیش از حد مجاز است. حداکثر حجم {max_mb} مگابایت است.",
            413,
            "FILE_TOO_LARGE",
        )


class MRZNotFoundError(PassportOCRError):
    def __init__(self):
        super().__init__(
            "ناحیه MRZ در تصویر پاسپورت پیدا نشد. تصویر واضح‌تر و کامل‌تری ارسال کنید.",
            422,
            "MRZ_NOT_FOUND",
        )


class TesseractNotFoundError(PassportOCRError):
    def __init__(self):
        super().__init__(
            "موتور Tesseract روی سیستم نصب نیست یا در PATH در دسترس نیست. ابتدا Tesseract OCR را نصب و سپس ترمینال را دوباره باز کنید.",
            503,
            "TESSERACT_NOT_FOUND",
        )
