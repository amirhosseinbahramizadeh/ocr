# Iraqi Passport OCR API

وب‌سرویس FastAPI برای OCR صفحه مشخصات پاسپورت عراقی.

## معماری

- `ImagePreprocessor`: decode، resize، deskew و بهبود کنتراست
- `MRZCropper`: یافتن و برش ناحیه MRZ با PassportEye
- `MRZParser`: نگاشت خروجی PassportEye به مدل پایدار API
- `ArabicPageOCR`: OCR متن عربی/انگلیسی صفحه با EasyOCR
- `PassportValidator`: کنترل کشور `IRQ` و checksumهای گزارش‌شده توسط PassportEye
- `PassportOCRService`: orchestration و ادغام خروجی‌ها

> نکته: OCR فیلدهای بصری عربی مبتنی بر label matching است. چیدمان نسخه‌های مختلف پاسپورت ممکن است متفاوت باشد؛ برای دقت production بهتر است ROI هر فیلد برای قالب واقعی پاسپورت سازمان شما کالیبره شود.

## اجرای محلی

### پیش‌نیاز سیستم

روی Ubuntu/Debian:

```bash
sudo apt-get update
sudo apt-get install -y tesseract-ocr tesseract-ocr-eng libgl1 libglib2.0-0 libgomp1
```

### Python

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

Swagger:

- `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`

## Docker

```bash
docker build -t iraqi-passport-ocr .
docker run --rm -p 8000:8000 iraqi-passport-ocr
```

یا:

```bash
docker compose up --build
```

## نمونه درخواست

```bash
curl -X POST "http://localhost:8000/api/v1/passport/ocr" \
  -H "accept: application/json" \
  -H "Content-Type: multipart/form-data" \
  -F "file=@passport.jpg"
```

## نمونه پاسخ

```json
{
  "success": true,
  "message": "اطلاعات پاسپورت با موفقیت استخراج شد.",
  "data": {
    "passport_number": "A1234567",
    "surname_latin": "AL SAMPLE",
    "given_names_latin": "ALI",
    "full_name_ar": "علي المثال",
    "surname_ar": null,
    "given_names_ar": null,
    "nationality": "IRQ",
    "issuing_country": "IRQ",
    "date_of_birth": "900101",
    "sex": "M",
    "expiration_date": "300101",
    "place_of_birth_ar": "بغداد"
  },
  "mrz": {
    "mrz_type": "TD3",
    "document_type": "P",
    "issuing_country": "IRQ",
    "nationality": "IRQ",
    "passport_number": "A1234567",
    "surname": "AL SAMPLE",
    "given_names": "ALI",
    "date_of_birth": "900101",
    "sex": "M",
    "expiration_date": "300101",
    "personal_number": null,
    "raw_text": null,
    "valid_score": 100,
    "checks": {
      "passport_number": true,
      "date_of_birth": true,
      "expiration_date": true,
      "composite": true
    },
    "source": {}
  },
  "visual_fields": {
    "passport_number": null,
    "full_name_ar": "علي المثال",
    "surname_ar": null,
    "given_names_ar": null,
    "place_of_birth_ar": "بغداد",
    "date_of_birth_text": null,
    "date_of_issue_text": null,
    "date_of_expiry_text": null,
    "sex_text": null,
    "raw_lines": []
  },
  "validation": {
    "is_iraqi_passport": true,
    "mrz_checks_passed": true,
    "warnings": []
  }
}
```

## نکات production

1. مدل EasyOCR در اولین درخواست load می‌شود؛ برای latency کمتر می‌توانید هنگام startup آن را warm-up کنید.
2. EasyOCR مدل‌هایش را در اولین اجرا دانلود می‌کند؛ در محیط بدون اینترنت، مدل‌ها را هنگام ساخت image از قبل cache کنید.
3. تصویر پاسپورت داده شخصی حساس است؛ ذخیره‌سازی فایل را به‌صورت پیش‌فرض انجام ندهید، لاگ‌ها را از PII پاک کنید و TLS/احراز هویت/محدودسازی نرخ را اضافه کنید.
4. برای دقت بالاتر فیلدهای عربی، بر اساس نمونه‌های واقعی و مجاز ROIهای ثابت/قابل‌تنظیم تعریف کنید و نتایج را با MRZ cross-check کنید.


## رفع خطا در Windows

اگر هنگام OCR خطای `TESSERACT_NOT_FOUND` دریافت کردید، Tesseract OCR را نصب کنید و پوشه نصب آن (معمولاً `C:\Program Files\Tesseract-OCR`) را به PATH اضافه کنید. سپس CMD/PowerShell را ببندید و دوباره باز کنید و این دستور را بررسی کنید:

```bat
tesseract --version
where tesseract
```

در نسخه اصلاح‌شده، تابع `deskew` خروجی `HoughLinesP` را با `reshape(-1, 4)` نرمال می‌کند تا با شکل خروجی OpenCV 4 و 5 سازگار باشد.

## GitHub Codespaces

این نسخه برای Codespaces آماده است. بعد از باز شدن Codespace و پایان `postCreateCommand`، اجرا کنید:

```bash
./start_codespace.sh
```

سپس از تب **Ports** پورت `8000` را در صورت نیاز روی **Public** قرار دهید و مسیر `/docs` را باز کنید.
