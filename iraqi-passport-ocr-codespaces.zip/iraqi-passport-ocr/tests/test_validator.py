from app.models.schemas import MRZFields
from app.services.validator import PassportValidator


def test_iraqi_valid_mrz():
    mrz = MRZFields(
        issuing_country="IRQ",
        nationality="IRQ",
        checks={
            "passport_number": True,
            "date_of_birth": True,
            "expiration_date": True,
            "composite": True,
        },
        valid_score=100,
    )
    result = PassportValidator().validate(mrz)
    assert result.is_iraqi_passport is True
    assert result.mrz_checks_passed is True
    assert result.warnings == []
